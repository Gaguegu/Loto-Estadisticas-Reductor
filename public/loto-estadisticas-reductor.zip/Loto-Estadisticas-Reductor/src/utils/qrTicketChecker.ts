import { GameType, LotteryDraw } from '../types';
import QRCode from 'qrcode';

export interface ScannedBet {
  index: number;
  numbers: number[];
  stars?: number[];
  reintegro?: number;
}

export type TicketScope = 'single' | 'weekly';

export interface ParsedTicketData {
  raw: string;
  game: GameType;
  date?: string; // YYYY-MM-DD if extracted or inferred
  startDate?: string;
  endDate?: string;
  drawStart?: number;
  drawEnd?: number;
  drawNumber?: string;
  reintegro?: number;
  joker?: string;
  bets: ScannedBet[];
  ticketCode?: string;
  isOfficialSELAECode: boolean;
  notes?: string;
  ticketScope?: TicketScope; // 'single' (1 sorteo diario) or 'weekly' (multisorteo semanal)
  priceEur?: number;
}

export interface BetScrutinyResult {
  index: number;
  numbers: number[];
  stars?: number[];
  hitNumbers: number[];
  numberHits: number;
  hitStars: number[];
  starHits: number;
  hasComplementario: boolean;
  hasReintegro: boolean;
  prizeCategory: string;
  isPrize: boolean;
  estimatedPrize: number;
}

export interface TicketScrutinyResult {
  game: GameType;
  draw: LotteryDraw;
  betsCount: number;
  winningBetsCount: number;
  totalWon: number;
  reintegroWon: boolean;
  bets: BetScrutinyResult[];
}

export const OFFICIAL_PRIZE_ESTIMATES: Record<GameType, Record<string, number>> = {
  primitiva: {
    'Esp. Cat (6 + R)': 15000000,
    '1ª Cat (6 Aciertos)': 1400000,
    '2ª Cat (5 + C)': 38000,
    '3ª Cat (5 Aciertos)': 2200,
    '4ª Cat (4 Aciertos)': 65,
    '5ª Cat (3 Aciertos)': 8,
    'Reintegro': 1.0,
  },
  bonoloto: {
    '1ª Cat (6 Aciertos)': 400000,
    '2ª Cat (5 + C)': 12000,
    '3ª Cat (5 Aciertos)': 850,
    '4ª Cat (4 Aciertos)': 28,
    '5ª Cat (3 Aciertos)': 4,
    'Reintegro': 0.5,
  },
  euromillones: {
    '1ª Cat (5 + 2★)': 50000000,
    '2ª Cat (5 + 1★)': 250000,
    '3ª Cat (5 + 0★)': 25000,
    '4ª Cat (4 + 2★)': 2500,
    '5ª Cat (4 + 1★)': 150,
    '6ª Cat (3 + 2★)': 75,
    '7ª Cat (4 + 0★)': 50,
    '8ª Cat (2 + 2★)': 20,
    '9ª Cat (3 + 1★)': 14,
    '10ª Cat (3 + 0★)': 10,
    '11ª Cat (1 + 2★)': 9,
    '12ª Cat (2 + 1★)': 7,
    '13ª Cat (2 + 0★)': 4,
  },
};

const SPANISH_MONTHS: Record<string, string> = {
  ENE: '01', ENERO: '01',
  FEB: '02', FEBRERO: '02',
  MAR: '03', MARZO: '03',
  ABR: '04', ABRIL: '04',
  MAY: '05', MAYO: '05',
  JUN: '06', JUNIO: '06',
  JUL: '07', JULIO: '07',
  AGO: '08', AGOSTO: '08',
  SEP: '09', SEPTIEMBRE: '09', SETIEMBRE: '09',
  OCT: '10', OCTUBRE: '10',
  NOV: '11', NOVIEMBRE: '11',
  DIC: '12', DICIEMBRE: '12',
};

function formatIsoDate(day: string, monthOrName: string, year: string): string {
  const y = year.length === 2 ? `20${year}` : year;
  let m = monthOrName.toUpperCase();
  if (SPANISH_MONTHS[m]) {
    m = SPANISH_MONTHS[m];
  } else {
    m = m.padStart(2, '0');
  }
  const d = day.padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Parses the raw text read from a QR code or barcode on a lottery slip.
 * Handles official SELAE format strings, query parameters, or plain list formats.
 */
export function parseTicketQR(qrText: string, defaultGame: GameType = 'primitiva'): ParsedTicketData {
  const trimmed = qrText.trim();
  let detectedGame: GameType = defaultGame;
  let reintegro: number | undefined = undefined;
  let date: string | undefined = undefined;
  let startDate: string | undefined = undefined;
  let endDate: string | undefined = undefined;
  let drawStart: number | undefined = undefined;
  let drawEnd: number | undefined = undefined;
  let drawNumber: string | undefined = undefined;
  let ticketCode: string | undefined = undefined;
  let priceEur: number | undefined = undefined;
  const bets: ScannedBet[] = [];
  let isOfficialSELAECode = false;
  let ticketScope: TicketScope = 'single';

  const lower = trimmed.toLowerCase();

  // Detect game from keywords or code prefixes
  if (lower.includes('euromillones') || lower.includes('emil') || lower.includes('euro') || lower.includes('j=em') || /^0[35]-\d{5}-/i.test(trimmed) || /^\d{5}-0[35]\d{2}-/.test(trimmed)) {
    detectedGame = 'euromillones';
  } else if (lower.includes('bonoloto') || lower.includes('bono') || lower.includes('j=bn') || lower.includes('j=bo') || /^02-\d{5}-/i.test(trimmed) || /^\d{5}-02\d{2}-/.test(trimmed)) {
    detectedGame = 'bonoloto';
  } else if (lower.includes('primitiva') || lower.includes('prim') || lower.includes('j=lp') || lower.includes('j=pr') || /^01-\d{5}-/i.test(trimmed) || /^\d{5}-01\d{2}-/.test(trimmed)) {
    detectedGame = 'primitiva';
  }

  // Check if it's an official SELAE receipt / QR code / terminal serial
  // Official barcodes look like: 13219-0202-16943-19642-34804-98941-41919
  // or QR code content: 02-13219-24F9A4F017CD31B88882F
  if (
    trimmed.includes('loteriasyapuestas.es') ||
    trimmed.includes('selae') ||
    /^\d{5}-\d{4}-\d{5}/.test(trimmed) ||
    /^\d{2}-\d{5}-[A-Z0-9]+/i.test(trimmed) ||
    /^[A-Z0-9]{15,45}$/i.test(trimmed)
  ) {
    isOfficialSELAECode = true;
    ticketCode = trimmed;
    // For official SELAE receipts where bets are encrypted in the QR, default to weekly
    // unless single-day price or date indicates otherwise
    ticketScope = 'weekly';
  }

  // 1. Detect Draw Range + Spanish Dates (e.g. "108 07 SEP 26 - 110 12 SEP 26")
  const drawRangeMatch = trimmed.match(
    /(\d+)\s+(\d{1,2})\s+([A-Za-z]{3,10})\s+(\d{2,4})\s*-\s*(\d+)\s+(\d{1,2})\s+([A-Za-z]{3,10})\s+(\d{2,4})/
  );
  if (drawRangeMatch) {
    drawStart = parseInt(drawRangeMatch[1], 10);
    startDate = formatIsoDate(drawRangeMatch[2], drawRangeMatch[3], drawRangeMatch[4]);
    drawEnd = parseInt(drawRangeMatch[5], 10);
    endDate = formatIsoDate(drawRangeMatch[6], drawRangeMatch[7], drawRangeMatch[8]);
    date = endDate;
    if (drawEnd > drawStart || startDate !== endDate) {
      ticketScope = 'weekly';
    }
  }

  // 2. Detect Date Range without draw numbers (e.g. "07 SEP 26 - 12 SEP 26" or "07/09/2026 - 12/09/2026")
  if (!startDate) {
    const textDateRange = trimmed.match(
      /(\d{1,2})\s+([A-Za-z]{3,10})\s+(\d{2,4})\s*(?:-|a|al|hasta)\s*(\d{1,2})\s+([A-Za-z]{3,10})\s+(\d{2,4})/i
    );
    if (textDateRange) {
      startDate = formatIsoDate(textDateRange[1], textDateRange[2], textDateRange[3]);
      endDate = formatIsoDate(textDateRange[4], textDateRange[5], textDateRange[6]);
      date = endDate;
      ticketScope = 'weekly';
    }
  }

  if (!startDate) {
    const numDateRange = trimmed.match(
      /(\d{2})[/-](\d{2})[/-](\d{2,4})\s*(?:-|a|al|hasta)\s*(\d{2})[/-](\d{2})[/-](\d{2,4})/
    );
    if (numDateRange) {
      startDate = formatIsoDate(numDateRange[1], numDateRange[2], numDateRange[3]);
      endDate = formatIsoDate(numDateRange[4], numDateRange[5], numDateRange[6]);
      date = endDate;
      ticketScope = 'weekly';
    }
  }

  // 3. Detect Single Spanish Date with optional draw number (e.g. "251 08 SEP 26", "108 07 SEP 26", or "08 SEP 26")
  if (!date) {
    const spanishSingleWithDraw = trimmed.match(/(?:^|[^\d])(\d{1,4})\s+(\d{1,2})\s+([A-Za-z]{3,10})\s+(\d{2,4})/);
    if (
      spanishSingleWithDraw &&
      parseInt(spanishSingleWithDraw[2], 10) >= 1 &&
      parseInt(spanishSingleWithDraw[2], 10) <= 31 &&
      SPANISH_MONTHS[spanishSingleWithDraw[3].toUpperCase()]
    ) {
      drawNumber = spanishSingleWithDraw[1];
      date = formatIsoDate(spanishSingleWithDraw[2], spanishSingleWithDraw[3], spanishSingleWithDraw[4]);
    } else {
      const spanishSingleDate = trimmed.match(/(?:^|[^\d])(\d{1,2})\s+([A-Za-z]{3,10})\s+(\d{2,4})/);
      if (spanishSingleDate && SPANISH_MONTHS[spanishSingleDate[2].toUpperCase()]) {
        date = formatIsoDate(spanishSingleDate[1], spanishSingleDate[2], spanishSingleDate[3]);
      }
    }
  }

  // 4. Detect Single Standard Date (YYYY-MM-DD or DD/MM/YYYY)
  if (!date) {
    const dateMatch = trimmed.match(/(\d{4})[/-](\d{2})[/-](\d{2})/) || trimmed.match(/(\d{2})[/-](\d{2})[/-](\d{4})/);
    if (dateMatch) {
      if (dateMatch[1].length === 4) {
        date = `${dateMatch[1]}-${dateMatch[2]}-${dateMatch[3]}`;
      } else {
        date = `${dateMatch[3]}-${dateMatch[2]}-${dateMatch[1]}`;
      }
    }
  }

  // 5. Detect Price in EUR (e.g. "6,00 EUR", "4,00 EUR", "0,50 EUR")
  const priceMatch = trimmed.match(/(\d+[.,]\d{2})\s*(?:EUR|€)/i);
  if (priceMatch) {
    priceEur = parseFloat(priceMatch[1].replace(',', '.'));
    // In Primitiva: 1 bet for 3 days = 3€, 2 bets for 3 days = 6€, 3 bets = 9€
    if (detectedGame === 'primitiva' && (priceEur === 3 || priceEur === 6 || priceEur === 9 || priceEur === 12)) {
      ticketScope = 'weekly';
    }
    // In Bonoloto: 4,00 € for 8 bets is 1 daily draw (0.50€ * 8 = 4.00€)
    if (detectedGame === 'bonoloto' && priceEur === 4.0 && !trimmed.toLowerCase().includes('semanal')) {
      ticketScope = 'single';
    }
  }

  // 6. Detect Reintegro if present (R=5 or R:5 or Reintegro: 5 or REINTEGRO: 5 or REINTEGRO: 0)
  const rMatch = trimmed.match(/(?:R|REINTEGRO)[=:\s]+(\d)/i);
  if (rMatch) {
    reintegro = parseInt(rMatch[1], 10);
  }

  // 7. Extract Bets from Lines
  // A bet consists of numbers, but lines may begin with "1.", "2.", "A:", "Apuesta 1:", etc.
  // We MUST strip leading bet indicators so the index number is never confused with a lottery number!
  const lines = trimmed.split(/[\r\n;,|]+/);

  for (const line of lines) {
    let cleanLine = line.trim();
    if (!cleanLine) continue;

    // Ignore lines that are header/meta information
    if (/^(?:la\s+)?primitiva|bonoloto|euromillones|selae|loterias|reintegro|joker|total|terminal|precio|importe/i.test(cleanLine)) {
      // Check if this line happens to contain bets as well
      if (!/\b\d{1,2}\s+\d{1,2}\s+\d{1,2}\s+\d{1,2}\s+\d{1,2}\b/.test(cleanLine)) {
        continue;
      }
    }

    // Strip leading bet indices: "1.", "2)", "A:", "Apuesta 1:", "1 -", etc.
    cleanLine = cleanLine.replace(/^\s*(?:(?:apuesta\s*)?[a-h\d]{1,2}[\.\)\-:]\s*)/i, '');

    // Check for stars separated by * or + or ★
    let numbersPart = cleanLine;
    let starsPart = '';

    if (cleanLine.includes('★')) {
      const parts = cleanLine.split('★');
      numbersPart = parts[0];
      starsPart = parts.slice(1).join(' ');
    } else if (cleanLine.includes('+') && detectedGame === 'euromillones') {
      const parts = cleanLine.split('+');
      numbersPart = parts[0];
      starsPart = parts[1];
    } else if (cleanLine.includes('*')) {
      const parts = cleanLine.split('*');
      numbersPart = parts[0];
      starsPart = parts.slice(1).join(' ');
    }

    // Extract all numbers between 1 and 50 (or 1 and 49)
    const allInts = (numbersPart.match(/\b\d{1,2}\b/g) || [])
      .map((n) => parseInt(n, 10))
      .filter((n) => n >= 1 && n <= (detectedGame === 'euromillones' ? 50 : 49));

    // Remove duplicates and sort
    const uniqueNumbers = Array.from(new Set(allInts)).sort((a, b) => a - b);

    const neededCount = detectedGame === 'euromillones' ? 5 : 6;
    if (uniqueNumbers.length >= neededCount) {
      const betNumbers = uniqueNumbers.slice(0, neededCount);
      let betStars: number[] | undefined = undefined;

      if (detectedGame === 'euromillones') {
        const starInts = (starsPart.match(/\b\d{1,2}\b/g) || [])
          .map((n) => parseInt(n, 10))
          .filter((n) => n >= 1 && n <= 12);
        const uniqueStars = Array.from(new Set(starInts)).sort((a, b) => a - b);
        if (uniqueStars.length >= 2) {
          betStars = uniqueStars.slice(0, 2);
        } else if (uniqueNumbers.length >= 7) {
          // Maybe stars were appended at the end of numbers
          betStars = uniqueNumbers.slice(5, 7).filter((s) => s <= 12);
        }
      }

      bets.push({
        index: bets.length + 1,
        numbers: betNumbers,
        stars: betStars,
        reintegro,
      });
    }
  }

  // If no bets were found via line parsing, search whole string for groups of numbers
  // (Do not do this for pure official SELAE serial hashes/barcodes where numbers are terminal IDs)
  if (bets.length === 0 && !isOfficialSELAECode) {
    const allInts = (trimmed.match(/\b\d{1,2}\b/g) || [])
      .map((n) => parseInt(n, 10))
      .filter((n) => n >= 1 && n <= (detectedGame === 'euromillones' ? 50 : 49));

    const neededCount = detectedGame === 'euromillones' ? 5 : 6;
    if (allInts.length >= neededCount) {
      // Chunk into bets
      let i = 0;
      while (i + neededCount <= allInts.length) {
        const chunk = allInts.slice(i, i + neededCount);
        const unique = Array.from(new Set(chunk)).sort((a, b) => a - b);
        if (unique.length === neededCount) {
          let stars: number[] | undefined = undefined;
          i += neededCount;
          if (detectedGame === 'euromillones' && i + 2 <= allInts.length) {
            const possibleStars = allInts.slice(i, i + 2).filter((s) => s <= 12);
            if (possibleStars.length === 2) {
              stars = possibleStars;
              i += 2;
            }
          }
          bets.push({
            index: bets.length + 1,
            numbers: unique,
            stars,
            reintegro,
          });
        } else {
          i++;
        }
      }
    }
  }

  // Check if ticket specifies weekly participation through explicit keywords
  if (
    /semanal|semana|abono|multisorteo|3\s*sorteos|2\s*sorteos|sem\.|3\s*d[ií]as|2\s*d[ií]as|tres\s*d[ií]as|tres\s*sorteos|para\s*los\s*tres|todos\s*los\s*sorteos|martes\s*y\s*viernes|lunes\s*a\s*domingo|lunes,\s*jueves\s*y\s*s[aá]bado/i.test(
      trimmed
    )
  ) {
    ticketScope = 'weekly';
  }

  return {
    raw: trimmed,
    game: detectedGame,
    date,
    startDate,
    endDate,
    drawStart,
    drawEnd,
    drawNumber,
    reintegro,
    bets,
    ticketCode,
    isOfficialSELAECode,
    ticketScope,
    priceEur,
    notes: isOfficialSELAECode
      ? 'Código oficial de resguardo detectado. En los boletos físicos oficiales de SELAE, el código QR contiene el identificador criptográfico del terminal. Puedes introducir o confirmar tus apuestas para comprobar los sorteos de la semana.'
      : undefined,
  };
}

export interface WeeklyDrawScrutiny {
  draw: LotteryDraw;
  dayOfWeek: string;
  date: string;
  dayLabel: string;
  dayFullTitle: string;
  scrutiny: TicketScrutinyResult;
  totalWon: number;
  winningBetsCount: number;
  bestPrizeCategory: string;
  hasReintegro: boolean;
  statusBadge: {
    text: string;
    isWon: boolean;
  };
}

export interface MultiDrawTicketScrutiny {
  game: GameType;
  ticket: ParsedTicketData;
  scope: TicketScope;
  weekStart: string;
  weekEnd: string;
  weekLabel: string;
  totalWon: number;
  totalWinningBets: number;
  drawsCount: number;
  winningDrawsCount: number;
  draws: WeeklyDrawScrutiny[];
}

/**
 * Returns the Monday (YYYY-MM-DD) of the ISO week containing the given date.
 */
export function getMondayOfWeek(dateStr: string): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const date = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  const day = date.getUTCDay(); // 0 = Sunday, 1 = Monday ... 6 = Saturday
  const diff = date.getUTCDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(Date.UTC(y, m - 1, diff, 12, 0, 0));
  return monday.toISOString().slice(0, 10);
}

/**
 * Returns the Sunday (YYYY-MM-DD) of the ISO week containing the given date.
 */
export function getSundayOfWeek(dateStr: string): string {
  const mondayStr = getMondayOfWeek(dateStr);
  const [y, m, d] = mondayStr.split('-').map(Number);
  const sunday = new Date(Date.UTC(y, m - 1, d + 6, 12, 0, 0));
  return sunday.toISOString().slice(0, 10);
}

/**
 * Formats a Spanish week label, e.g. "Semana del 7 al 13 de Septiembre de 2026"
 */
export function getWeekSpanishLabel(dateStr: string): string {
  const mondayStr = getMondayOfWeek(dateStr);
  const sundayStr = getSundayOfWeek(dateStr);

  const months = [
    'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
    'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  ];

  const mParts = mondayStr.split('-').map(Number);
  const sParts = sundayStr.split('-').map(Number);

  const mDay = mParts[2];
  const sDay = sParts[2];
  const mMonth = months[mParts[1] - 1];
  const sMonth = months[sParts[1] - 1];
  const year = sParts[0];

  if (mMonth === sMonth) {
    return `Semana del ${mDay} al ${sDay} de ${sMonth} de ${year}`;
  }
  return `Semana del ${mDay} de ${mMonth} al ${sDay} de ${sMonth} de ${year}`;
}

/**
 * Filters all draws that occurred within the ISO week of referenceDate for the specified game.
 * Sorted chronologically (Monday -> Sunday).
 */
export function getDrawsForWeek(
  allDraws: LotteryDraw[],
  referenceDate: string,
  game: GameType
): LotteryDraw[] {
  const mondayStr = getMondayOfWeek(referenceDate);
  const sundayStr = getSundayOfWeek(referenceDate);

  return allDraws
    .filter((d) => d.game === game && d.date >= mondayStr && d.date <= sundayStr)
    .sort((a, b) => a.date.localeCompare(b.date)); // Chronological order
}

/**
 * Scrutinizes a ticket across one or multiple draws (Weekly / Multi-draw).
 * In Primitiva: Lunes, Jueves, Sábado.
 * In Bonoloto: Toda la semana (Lunes a Domingo).
 * In Euromillones: Martes y Viernes.
 */
export function scrutinizeMultiDrawTicket(
  ticket: ParsedTicketData,
  draws: LotteryDraw[],
  customReintegro?: number,
  scope: TicketScope = 'weekly'
): MultiDrawTicketScrutiny {
  const referenceDate = draws.length > 0 ? draws[0].date : new Date().toISOString().slice(0, 10);
  const mondayStr = getMondayOfWeek(referenceDate);
  const sundayStr = getSundayOfWeek(referenceDate);
  const weekLabel = getWeekSpanishLabel(referenceDate);

  let totalWon = 0;
  let totalWinningBets = 0;
  let winningDrawsCount = 0;

  const scrutinizedDraws: WeeklyDrawScrutiny[] = draws.map((draw) => {
    const scrutiny = scrutinizeTicket(ticket, draw, customReintegro);
    totalWon += scrutiny.totalWon;
    totalWinningBets += scrutiny.winningBetsCount;
    if (scrutiny.totalWon > 0 || scrutiny.winningBetsCount > 0) {
      winningDrawsCount++;
    }

    const winningBets = scrutiny.bets.filter((b) => b.isPrize);
    let bestPrizeCategory = 'Sin premio';
    if (winningBets.length > 0) {
      const sorted = [...winningBets].sort((a, b) => b.estimatedPrize - a.estimatedPrize);
      bestPrizeCategory = sorted[0].prizeCategory;
    }

    const dayName = draw.dayOfWeek || 'Sorteo';
    const parts = draw.date.split('-');
    const formattedShort = `${parts[2]}/${parts[1]}`;
    const formattedFull = `${parts[2]}/${parts[1]}/${parts[0]}`;

    let badgeText = 'Sin premio (0,00 €)';
    let isWon = false;
    if (scrutiny.totalWon > 0) {
      isWon = true;
      badgeText = `${scrutiny.winningBetsCount} premio(s): +${scrutiny.totalWon.toLocaleString('es-ES', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      })} €`;
    }

    return {
      draw,
      dayOfWeek: dayName,
      date: draw.date,
      dayLabel: `${dayName} ${formattedShort}`,
      dayFullTitle: `${dayName}, ${formattedFull}`,
      scrutiny,
      totalWon: scrutiny.totalWon,
      winningBetsCount: scrutiny.winningBetsCount,
      bestPrizeCategory,
      hasReintegro: scrutiny.reintegroWon,
      statusBadge: {
        text: badgeText,
        isWon,
      },
    };
  });

  return {
    game: ticket.game,
    ticket,
    scope,
    weekStart: mondayStr,
    weekEnd: sundayStr,
    weekLabel,
    totalWon,
    totalWinningBets,
    drawsCount: draws.length,
    winningDrawsCount,
    draws: scrutinizedDraws,
  };
}

/**
 * Scrutinizes parsed bets against a specific official lottery draw.
 */
export function scrutinizeTicket(
  ticket: ParsedTicketData,
  draw: LotteryDraw,
  customReintegro?: number
): TicketScrutinyResult {
  const effectiveReintegro = customReintegro !== undefined ? customReintegro : ticket.reintegro;
  const winningSet = new Set(draw.numbers);
  const winningStarsSet = new Set(draw.stars || []);

  const estimates = OFFICIAL_PRIZE_ESTIMATES[ticket.game];
  let totalWon = 0;
  let winningBetsCount = 0;
  let reintegroWon = false;

  const betsResult: BetScrutinyResult[] = ticket.bets.map((bet) => {
    const hitNumbers = bet.numbers.filter((n) => winningSet.has(n));
    const numberHits = hitNumbers.length;

    const hitStars = bet.stars ? bet.stars.filter((s) => winningStarsSet.has(s)) : [];
    const starHits = hitStars.length;

    const hasComplementario =
      draw.complementario !== undefined && bet.numbers.includes(draw.complementario);

    const betR = bet.reintegro !== undefined ? bet.reintegro : effectiveReintegro;
    const hasReintegro =
      ticket.game !== 'euromillones' &&
      draw.reintegro !== undefined &&
      betR !== undefined &&
      betR === draw.reintegro;

    if (hasReintegro) {
      reintegroWon = true;
    }

    let isPrize = false;
    let prizeCategory = 'Sin premio';
    let estimatedPrize = 0;

    if (ticket.game === 'euromillones') {
      if (numberHits === 5 && starHits === 2) {
        isPrize = true;
        prizeCategory = '1ª Cat (5 + 2★)';
      } else if (numberHits === 5 && starHits === 1) {
        isPrize = true;
        prizeCategory = '2ª Cat (5 + 1★)';
      } else if (numberHits === 5 && starHits === 0) {
        isPrize = true;
        prizeCategory = '3ª Cat (5 + 0★)';
      } else if (numberHits === 4 && starHits === 2) {
        isPrize = true;
        prizeCategory = '4ª Cat (4 + 2★)';
      } else if (numberHits === 4 && starHits === 1) {
        isPrize = true;
        prizeCategory = '5ª Cat (4 + 1★)';
      } else if (numberHits === 3 && starHits === 2) {
        isPrize = true;
        prizeCategory = '6ª Cat (3 + 2★)';
      } else if (numberHits === 4 && starHits === 0) {
        isPrize = true;
        prizeCategory = '7ª Cat (4 + 0★)';
      } else if (numberHits === 2 && starHits === 2) {
        isPrize = true;
        prizeCategory = '8ª Cat (2 + 2★)';
      } else if (numberHits === 3 && starHits === 1) {
        isPrize = true;
        prizeCategory = '9ª Cat (3 + 1★)';
      } else if (numberHits === 3 && starHits === 0) {
        isPrize = true;
        prizeCategory = '10ª Cat (3 + 0★)';
      } else if (numberHits === 1 && starHits === 2) {
        isPrize = true;
        prizeCategory = '11ª Cat (1 + 2★)';
      } else if (numberHits === 2 && starHits === 1) {
        isPrize = true;
        prizeCategory = '12ª Cat (2 + 1★)';
      } else if (numberHits === 2 && starHits === 0) {
        isPrize = true;
        prizeCategory = '13ª Cat (2 + 0★)';
      } else {
        prizeCategory = `${numberHits} aciertos`;
      }
    } else {
      // Primitiva and Bonoloto
      if (numberHits === 6) {
        isPrize = true;
        prizeCategory = hasReintegro ? 'Esp. Cat (6 + R)' : '1ª Cat (6 Aciertos)';
      } else if (numberHits === 5 && hasComplementario) {
        isPrize = true;
        prizeCategory = '2ª Cat (5 + C)';
      } else if (numberHits === 5) {
        isPrize = true;
        prizeCategory = '3ª Cat (5 Aciertos)';
      } else if (numberHits === 4) {
        isPrize = true;
        prizeCategory = '4ª Cat (4 Aciertos)';
      } else if (numberHits === 3) {
        isPrize = true;
        prizeCategory = '5ª Cat (3 Aciertos)';
      } else if (hasReintegro) {
        isPrize = true;
        prizeCategory = 'Reintegro';
      } else {
        prizeCategory = `${numberHits} aciertos`;
      }
    }

    if (isPrize) {
      winningBetsCount++;
      estimatedPrize = estimates[prizeCategory] || (hasReintegro ? estimates['Reintegro'] || 1 : 0);
      totalWon += estimatedPrize;
    }

    return {
      index: bet.index,
      numbers: bet.numbers,
      stars: bet.stars,
      hitNumbers,
      numberHits,
      hitStars,
      starHits,
      hasComplementario,
      hasReintegro,
      prizeCategory,
      isPrize,
      estimatedPrize,
    };
  });

  return {
    game: ticket.game,
    draw,
    betsCount: ticket.bets.length,
    winningBetsCount,
    totalWon,
    reintegroWon,
    bets: betsResult,
  };
}

/**
 * Generates the standardized QR text payload for a group of bets (e.g. an official 8-bet slip).
 * This format is 100% compatible with parseTicketQR.
 */
export function generateTicketQRText(
  game: GameType,
  bets: { id?: number; numbers: number[]; stars?: number[]; reintegro?: number }[],
  options?: { reintegro?: number; date?: string; title?: string }
): string {
  const gameName =
    game === 'primitiva'
      ? 'LA PRIMITIVA - SELAE'
      : game === 'bonoloto'
      ? 'BONOLOTO - SELAE'
      : 'EUROMILLONES - SELAE';

  const lines: string[] = [gameName];
  if (options?.title) {
    lines.push(options.title);
  }
  if (options?.date) {
    lines.push(`FECHA: ${options.date}`);
  }

  bets.forEach((bet, idx) => {
    const nums = bet.numbers.map((n) => n.toString().padStart(2, '0')).join(' ');
    if (game === 'euromillones' && bet.stars && bet.stars.length > 0) {
      const stars = bet.stars.map((s) => s.toString().padStart(2, '0')).join(' ');
      lines.push(`${idx + 1}. ${nums} + ${stars}`);
    } else {
      lines.push(`${idx + 1}. ${nums}`);
    }
  });

  const r = options?.reintegro ?? bets.find((b) => b.reintegro !== undefined)?.reintegro;
  if (r !== undefined && game !== 'euromillones') {
    lines.push(`REINTEGRO: ${r}`);
  }

  return lines.join('\n');
}

/**
 * Generates a PNG data URL for the given QR code text.
 */
export async function generateTicketQRCodeDataUrl(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      margin: 1,
      width: 240,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    });
  } catch (err) {
    console.error('Error generando código QR:', err);
    return '';
  }
}

